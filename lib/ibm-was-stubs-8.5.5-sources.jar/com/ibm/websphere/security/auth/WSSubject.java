package com.ibm.websphere.security.auth;

import javax.security.auth.Subject;

/** Compile-time stub of the IBM WAS API (version 8.5.5). The WAS container provides the real class at runtime. */
public class WSSubject {
    public static Subject getCallerSubject() throws com.ibm.websphere.security.WSSecurityException {
        return null;  // stub: WAS container provides the real implementation
    }

    public static String getCallerPrincipal() throws com.ibm.websphere.security.WSSecurityException {
        return null;
    }
}
