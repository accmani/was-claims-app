package com.ibm.websphere.security;

/** Compile-time stub of the IBM WAS API (version 8.5.5). The WAS container provides the real class at runtime. */
public class WSSecurityException extends Exception {
    public WSSecurityException(String message) { super(message); }
    public WSSecurityException(String message, Throwable cause) { super(message, cause); }
}
