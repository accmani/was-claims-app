package com.ibm.websphere.security.cred;

import java.util.List;

/** Compile-time stub of the IBM WAS API (version 8.5.5). The WAS container provides the real class at runtime. */
public class WSCredential {
    public String getSecurityName() { return null; }
    @SuppressWarnings("rawtypes")
    public List getRoles() { return null; }
    public String getRealmName() { return null; }
    public boolean isUnauthenticated() { return true; }
}
